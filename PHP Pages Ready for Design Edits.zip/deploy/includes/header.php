<?php
// Site paths are worked out automatically, so the site runs from the domain root or a sub-folder.
$baseUrl = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$siteUrl = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . $baseUrl;

$pageTitle = $pageTitle ?? 'PureLine Water Filtration';
$pageDescription = $pageDescription ?? 'Whole house water filtration for Australian homes, professionally installed by licensed plumbers.';
$canonicalUrl = $canonicalUrl ?? $siteUrl . ($canonicalPath ?? '/');
$extraHead = $extraHead ?? '';
$robots = $robots ?? '';
$bodyClass = $bodyClass ?? '';

$faqSchema = [];
foreach (($faqs ?? []) as $faq) {
    if (empty($faq['schema'])) {
        continue;
    }

    $faqSchema[] = [
        '@type' => 'Question',
        'name' => $faq['question'],
        'acceptedAnswer' => [
            '@type' => 'Answer',
            'text' => $faq['answer'],
        ],
    ];
}

$structuredData = [
    '@context' => 'https://schema.org',
    '@graph' => [
        [
            '@type' => 'Organization',
            '@id' => $siteUrl . '/#organization',
            'name' => 'PureLine Water Filtration',
            'url' => $siteUrl . '/',
            'email' => 'info@purelinewaterfiltration.com.au',
            'telephone' => '+61-1300-011-406',
            'address' => [
                '@type' => 'PostalAddress',
                'streetAddress' => '46 Palladium Circuit',
                'addressLocality' => 'Clyde North',
                'addressRegion' => 'VIC',
                'postalCode' => '3978',
                'addressCountry' => 'AU',
            ],
        ],
        [
            '@type' => 'WebSite',
            '@id' => $siteUrl . '/#website',
            'url' => $siteUrl . '/',
            'name' => 'PureLine Water Filtration',
            'publisher' => ['@id' => $siteUrl . '/#organization'],
            'inLanguage' => 'en-AU',
        ],
        [
            '@type' => 'LocalBusiness',
            '@id' => $siteUrl . '/#localbusiness',
            'name' => 'PureLine Water Filtration',
            'url' => $siteUrl . '/',
            'telephone' => '+61-1300-011-406',
            'email' => 'info@purelinewaterfiltration.com.au',
            'sameAs' => [
                'https://www.facebook.com/purelinewaterfiltration',
                'https://www.instagram.com/purelinewaterfiltration',
            ],
            'address' => [
                '@type' => 'PostalAddress',
                'streetAddress' => '46 Palladium Circuit',
                'addressLocality' => 'Clyde North',
                'addressRegion' => 'VIC',
                'postalCode' => '3978',
                'addressCountry' => 'AU',
            ],
        ],
        [
            '@type' => 'Service',
            '@id' => $siteUrl . '/#service',
            'name' => 'Whole house water filtration system installation',
            'provider' => ['@id' => $siteUrl . '/#organization'],
            'url' => $siteUrl . '/whole-house-water-filter.php',
            'description' => 'Assessment and licensed-plumber installation of whole-house water filtration systems for residential properties.',
        ],
    ],
];

if (($pageType ?? '') === 'about') {
    $structuredData['@graph'][] = [
        '@type' => 'AboutPage',
        '@id' => $canonicalUrl . '#about-page',
        'url' => $canonicalUrl,
        'name' => $pageTitle,
        'description' => $pageDescription,
        'about' => ['@id' => $siteUrl . '/#organization'],
        'isPartOf' => ['@id' => $siteUrl . '/#website'],
        'inLanguage' => 'en-AU',
    ];
    $structuredData['@graph'][] = [
        '@type' => 'BreadcrumbList',
        '@id' => $canonicalUrl . '#breadcrumb',
        'itemListElement' => [
            ['@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => $siteUrl . '/'],
            ['@type' => 'ListItem', 'position' => 2, 'name' => 'About Us', 'item' => $canonicalUrl],
        ],
    ];
}

foreach (($extraStructuredData ?? []) as $entity) {
    $structuredData['@graph'][] = $entity;
}

if ($faqSchema !== []) {
    $structuredData['@graph'][] = [
        '@type' => 'FAQPage',
        '@id' => $canonicalUrl . '#faq',
        'url' => $canonicalUrl,
        'mainEntity' => $faqSchema,
        'inLanguage' => 'en-AU',
    ];
}
?>
<!doctype html>
<html lang="en-AU">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription, ENT_QUOTES, 'UTF-8'); ?>">
<?php if ($robots !== '') : ?>    <meta name="robots" content="<?php echo htmlspecialchars($robots, ENT_QUOTES, 'UTF-8'); ?>">
<?php endif; ?>    <meta name="theme-color" content="#f6fafb">
    <link rel="icon" href="<?php echo $baseUrl; ?>/favicon.ico" sizes="32x32">
    <link rel="icon" type="image/svg+xml" href="<?php echo $baseUrl; ?>/assets/images/favicon.svg">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo $baseUrl; ?>/favicon-32x32.png">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo $baseUrl; ?>/apple-touch-icon.png">
    <link rel="canonical" href="<?php echo htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8'); ?>">
    <meta property="og:type" content="website">
    <meta property="og:locale" content="en_AU">
    <meta property="og:site_name" content="PureLine Water Filtration">
    <meta property="og:title" content="<?php echo htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8'); ?>">
    <meta property="og:description" content="<?php echo htmlspecialchars($pageDescription, ENT_QUOTES, 'UTF-8'); ?>">
    <meta property="og:url" content="<?php echo htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8'); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>/assets/css/style.css">
    <script type="application/ld+json"><?php echo json_encode($structuredData, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?></script>
<?php if ($extraHead !== '') { echo $extraHead . "\n"; } ?>
    <script src="<?php echo $baseUrl; ?>/assets/js/main.js" defer></script>
</head>
<body class="<?php echo htmlspecialchars($bodyClass, ENT_QUOTES, 'UTF-8'); ?>">
<a class="skip-link" href="#main-content">Skip to content</a>
<div class="utility-bar">
    <div class="section-shell utility-bar__inner">
        <p><svg class="utility-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 10c0 6-8 11-8 11S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></svg>We're based in Clyde North, Victoria</p>
        <div class="utility-bar__links">
            <a href="tel:1300011406"><svg class="utility-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m7 3 3 5-3 3a16 16 0 0 0 6 6l3-3 5 3c-1 4-3 5-7 3A24 24 0 0 1 4 10C2 6 3 4 7 3Z"/></svg>1300 011 406</a>
            <a href="mailto:info@purelinewaterfiltration.com.au"><svg class="utility-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 6 9 7 9-7"/></svg>info@purelinewaterfiltration.com.au</a>
            <a href="<?php echo $baseUrl; ?>/become-a-dealer.php"><svg class="utility-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="7" width="18" height="14" rx="2"/><path d="M8 7V3h8v4M3 12h18m-11-2v4h4v-4"/></svg>Become a Dealer</a>
        </div>
    </div>
</div>
<header class="site-header" id="site-header">
    <div class="section-shell site-header__inner">
        <a class="brand" href="<?php echo $baseUrl; ?>/" aria-label="PureLine Water Filtration home">
            <img src="<?php echo $baseUrl; ?>/assets/images/logo.png" alt="Pureline Water Filtration" width="1042" height="384">
        </a>
        <button class="menu-toggle" type="button" aria-label="Open navigation menu" aria-expanded="false" aria-controls="site-navigation">
            <span></span><span></span><span></span>
        </button>
        <nav class="site-nav" id="site-navigation" aria-label="Main navigation">
            <a href="<?php echo $baseUrl; ?>/"<?php echo $bodyClass === 'home-page' ? ' aria-current="page"' : ''; ?>>Home</a>
            <a href="<?php echo $baseUrl; ?>/about-us.php"<?php echo $bodyClass === 'about-page' ? ' aria-current="page"' : ''; ?>>About Us</a>
            <a href="<?php echo $baseUrl; ?>/whole-house-water-filter.php"<?php echo $bodyClass === 'filter-page' ? ' aria-current="page"' : ''; ?>>Water Filtration System</a>
            <a href="<?php echo $baseUrl; ?>/benefits.php"<?php echo $bodyClass === 'benefits-page' ? ' aria-current="page"' : ''; ?>>Benefits</a>
            <a class="site-nav__dealer" href="<?php echo $baseUrl; ?>/become-a-dealer.php"<?php echo $bodyClass === 'dealer-page' ? ' aria-current="page"' : ''; ?>>Become a Dealer</a>
            <a class="site-nav__mobile-quote" href="<?php echo $baseUrl; ?>/request-a-quote.php">Request a Free Quote <span aria-hidden="true">&#8594;</span></a>
        </nav>
        <div class="site-header__actions">
            <a class="header-phone" href="tel:1300011406"><span class="header-phone__icon" aria-hidden="true">&#9742;</span><span>1300 011 406</span></a>
            <a class="button button--small" href="<?php echo $baseUrl; ?>/request-a-quote.php">Request a Free Quote <span aria-hidden="true">&#8594;</span></a>
        </div>
    </div>
</header>
