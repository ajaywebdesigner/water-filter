<footer class="site-footer">
    <div class="section-shell footer-main">
        <div class="footer-brand">
            <a class="brand brand--footer" href="<?php echo $baseUrl; ?>/" aria-label="PureLine Water Filtration home">
                <img src="<?php echo $baseUrl; ?>/assets/images/logo.png" alt="Pureline Water Filtration" width="1042" height="384" loading="lazy" decoding="async">
            </a>
            <p>PureLine Water Filtration helps Australian households improve water quality throughout the home with professionally installed whole-house filtration systems.</p>
        </div>
        <div class="footer-column">
            <h2>Quick Links</h2>
            <ul><li><a href="<?php echo $baseUrl; ?>/">Home</a></li><li><a href="<?php echo $baseUrl; ?>/about-us.php">About Us</a></li><li><a href="<?php echo $baseUrl; ?>/whole-house-water-filter.php">Water Filtration System</a></li><li><a href="<?php echo $baseUrl; ?>/benefits.php">Benefits</a></li><li><a href="<?php echo $baseUrl; ?>/request-a-quote.php">Request a Quote</a></li></ul>
        </div>
        <div class="footer-column">
            <h2>Dealership &amp; Enquiries</h2>
            <ul><li><a href="<?php echo $baseUrl; ?>/become-a-dealer.php">Become a Dealer</a></li><li><a href="<?php echo $baseUrl; ?>/dealer-eoi-form.php">Dealer EOI</a></li><li><a href="<?php echo $baseUrl; ?>/request-a-quote.php">Request a Quote</a></li></ul>
        </div>
        <div class="footer-column footer-contact">
            <h2>Contact</h2>
            <a href="tel:1300011406">1300 011 406</a>
            <a href="mailto:info@purelinewaterfiltration.com.au">info@purelinewaterfiltration.com.au</a>
            <address>46 Palladium Circuit,<br>Clyde North VIC 3978</address>
            <p class="footer-abn">ABN: <strong>XX XXX XXX XXX</strong></p>
        </div>
    </div>
    <div class="section-shell footer-bottom">
        <p class="footer-copyright">&copy; <?php echo date('Y'); ?> Pure Line Water Filtration. All Rights Reserved. Website Design &amp; Marketing By <a href="https://ardigitalsolutions.com.au/">AR Digital Solutions</a></p>
        <div class="footer-social" aria-label="Social media">
            <a href="https://www.facebook.com/purelinewaterfiltration" target="_blank" rel="noopener noreferrer" aria-label="PureLine on Facebook"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M13.5 22v-9h3l.5-3.5h-3.5V7.3c0-1 .3-1.8 1.8-1.8H17V2.3c-.8-.1-1.7-.3-2.6-.3-2.7 0-4.4 1.6-4.4 4.6v2.9H7V13h3v9z"/></svg></a>
            <a href="https://www.instagram.com/purelinewaterfiltration" target="_blank" rel="noopener noreferrer" aria-label="PureLine on Instagram"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true" focusable="false"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg></a>
        </div>
        <div class="footer-legal"><a href="#">Privacy Policy</a><mark class="content-gap">[GAP: page needed]</mark></div>
    </div>
</footer>
</body>
</html>
