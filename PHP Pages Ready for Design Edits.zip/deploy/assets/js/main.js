/* PureLine Water Filtration: site interactions */
(() => {
    const root = document.documentElement;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    root.classList.add('js');

    /* Header: scroll shadow and mobile menu */
    const header = document.getElementById('site-header');
    const toggle = document.querySelector('.menu-toggle');
    const nav = document.getElementById('site-navigation');
    const onScroll = () => { if (header) header.classList.toggle('site-header--scrolled', window.scrollY > 8); };
    const setMenu = (open) => {
        if (!toggle || !nav) return;
        nav.classList.toggle('site-nav--open', open);
        document.body.classList.toggle('menu-open', open);
        toggle.setAttribute('aria-expanded', String(open));
        toggle.setAttribute('aria-label', open ? 'Close navigation menu' : 'Open navigation menu');
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    if (toggle) toggle.addEventListener('click', () => setMenu(!nav.classList.contains('site-nav--open')));
    if (nav) nav.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => setMenu(false)));
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setMenu(false); });
    window.matchMedia('(min-width: 901px)').addEventListener('change', () => setMenu(false));

    /* FAQ accordions */
    document.querySelectorAll('.faq-trigger').forEach((btn) => {
        btn.addEventListener('click', () => {
            const panel = document.getElementById(btn.getAttribute('aria-controls'));
            const open = btn.getAttribute('aria-expanded') !== 'true';
            btn.setAttribute('aria-expanded', String(open));
            if (panel) panel.hidden = !open;
        });
    });

    /* Reveal on scroll */
    const reveals = document.querySelectorAll('.reveal');
    if (!reduce && 'IntersectionObserver' in window) {
        const rio = new IntersectionObserver((entries, obs) => {
            entries.forEach((e) => { if (!e.isIntersecting) return; e.target.classList.add('is-visible'); obs.unobserve(e.target); });
        }, { threshold: 0.12, rootMargin: '0px 0px -36px 0px' });
        reveals.forEach((el) => rio.observe(el));
    } else {
        reveals.forEach((el) => el.classList.add('is-visible'));
    }

    /* Entrance animations and icon line drawing */
    if (!reduce && 'IntersectionObserver' in window) {
        root.classList.add('anim-ready');
        const groups = [
          ['.section-heading, .faq-heading, .benefits-section-heading, .about-cert-heading, .about-cert-intro, .filter-limits-heading, .stages-specialty, .benefits-link, .about-dealers, .about-operations-heading, .about-operations-copy', 'up', false],
          ['.error-content > *', 'up', true],
          ['.qc-tile, .qn-step, .wd-card, .sv-side, .gs-step, .suits-list li, .hw-step, .hw-promise, .trust-card, .stage-card, .benefit-card, .reason-card, .process-step, .about-value, .about-cert-card, .about-purpose-card, .filter-facts > article, .filter-care-card, .filter-stage, .dealer-support-card, .dealer-start li, .quote-next li, .faq-item, .filter-limit-card, .benefits-grid > article, .benefits-small-grid > *, .footer-main > *, .about-cert-links > *, .benefits-faq', 'up', true],
          ['.about-expect li, .benefits-checklist li, .dealer-suits li, .quote-ready li, .filter-checks li, .benefits-limits li, .about-standards-list article', 'left', true],
          ['.pfas-values > div', 'right', true],
          ['.comparison-table tbody tr, .filter-specs:not(.filter-specs--v2) tbody tr, .filter-stage-table tbody tr', 'fade', true],
          ['.story-media, .suits-band, .bd-media, .bd-copy, .hw-panel, .intro-visual, .builder-image, .about-origin-photo, .benefits-fit__image, .filter-limits-photo, .dealer-section-photo, .regional-map, .process-heading-image, .quote-form-panel, .eoi-form-panel, .about-operations-panel, .filter-spec-wrap, .filter-stage-table-wrap, .comparison-table-wrap, .pfas-panel, .benefits-limits, .dealer-values, .quote-contact, .quote-ready, .benefits-savings, .eoi-context > *, .quote-office-map, .about-expect', 'zoom', true],
          ['.benefit-card__icon, .about-value-icon, .about-cert-icon, .filter-detail-icon, .filter-limit-icon, .about-purpose-icon, .dealer-card-mark, .stage-card__symbol, .stage-number, .filter-stage-badge', 'pop', false]
        ];
        const drawSel = '.spec-ico svg, .qn-step__icon svg, .wd-card__icon svg, .sv-item__icon svg, .ds-card__icon svg, .hw-step__icon svg, .hw-check svg, .reason-card__icon svg, .trust-card__icon svg, .benefit-card__icon svg, .about-value-icon svg, .about-cert-icon svg, .filter-detail-icon svg, .filter-limit-icon svg, .about-purpose-icon svg, .hero__proof svg, .eoi-context svg';
        const aio = new IntersectionObserver((entries, obs) => {
            entries.forEach((e) => {
                if (!e.isIntersecting) return;
                const el = e.target;
                el.classList.add(el.classList.contains('anim-draw') ? 'anim-drawn' : 'anim-in');
                obs.unobserve(el);
            });
        }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
        const tagged = new WeakSet();
        groups.forEach(([sel, type, stagger]) => {
            document.querySelectorAll(sel).forEach((el) => {
                if (tagged.has(el) || el.classList.contains('reveal')) return;
                tagged.add(el);
                let idx = 0;
                if (stagger && el.parentElement) idx = Array.from(el.parentElement.children).filter((c) => c.matches(sel)).indexOf(el);
                el.classList.add('anim', 'anim--' + type);
                el.style.setProperty('--anim-d', (Math.min(idx, 6) * 90 + (type === 'pop' ? 220 : 0)) + 'ms');
                aio.observe(el);
            });
        });
        document.querySelectorAll(drawSel).forEach((svg) => {
            if (tagged.has(svg) || svg.getAttribute('fill') !== 'none') return;
            tagged.add(svg);
            svg.querySelectorAll('path, circle, rect, line, polyline, ellipse').forEach((s) => s.setAttribute('pathLength', '1'));
            svg.classList.add('anim-draw');
            aio.observe(svg);
        });
    }

    /* Tilt + spotlight cards */
    document.querySelectorAll('.reason-card--v2, .ds-card').forEach((el) => {
        el.addEventListener('mousemove', (ev) => {
            const r = el.getBoundingClientRect();
            const x = (ev.clientX - r.left) / r.width;
            const y = (ev.clientY - r.top) / r.height;
            el.style.setProperty('--mx', (x * 100) + '%');
            el.style.setProperty('--my', (y * 100) + '%');
            if (!reduce) el.style.transform = 'perspective(900px) rotateX(' + ((0.5 - y) * 6) + 'deg) rotateY(' + ((x - 0.5) * 8) + 'deg) translateY(-6px)';
        });
        el.addEventListener('mouseleave', () => { el.style.transform = ''; });
    });

    /* CTA spotlight */
    document.querySelectorAll('.final-cta--rich').forEach((el) => {
        el.addEventListener('pointermove', (ev) => {
            const r = el.getBoundingClientRect();
            el.style.setProperty('--cx', ((ev.clientX - r.left) / r.width * 100) + '%');
            el.style.setProperty('--cy', ((ev.clientY - r.top) / r.height * 100) + '%');
        });
    });

    /* Home: installation timeline */
    const track = document.querySelector('.process-track');
    if (track) {
        const steps = Array.from(track.querySelectorAll('.process-step'));
        const dots = Array.from(document.querySelectorAll('.process-dot'));
        const count = document.querySelector('.process-photo__count');
        let current = 1;
        let hold = false;
        let holdTimer = 0;
        const setStep = (n) => {
            current = n;
            steps.forEach((s, i) => {
                s.classList.toggle('is-done', i + 1 < n);
                s.classList.toggle('is-active', i + 1 === n);
            });
            dots.forEach((d, i) => d.classList.toggle('is-on', i + 1 <= n));
            if (count) count.textContent = '0' + n;
            track.style.setProperty('--process-fill', ((n - 1) / Math.max(steps.length - 1, 1) * 100) + '%');
        };
        const pick = (n) => {
            hold = true;
            clearTimeout(holdTimer);
            holdTimer = setTimeout(() => { hold = false; }, 1200);
            if (n !== current) setStep(n);
        };
        steps.forEach((s, i) => { s.addEventListener('click', () => pick(i + 1)); s.addEventListener('mouseenter', () => pick(i + 1)); });
        dots.forEach((d, i) => d.addEventListener('click', () => pick(i + 1)));
        const onTrackScroll = () => {
            const r = track.getBoundingClientRect();
            const vh = window.innerHeight;
            if (r.bottom < 0 || r.top > vh || hold) return;
            const mark = vh * 0.55;
            let s = 1;
            steps.forEach((it, i) => { if (it.getBoundingClientRect().top < mark) s = i + 1; });
            if (s !== current) setStep(s);
        };
        window.addEventListener('scroll', onTrackScroll, { passive: true });
        setStep(1);
        onTrackScroll();
    }

    /* Benefits: explorer tabs */
    const bx = document.querySelector('.bx');
    if (bx) {
        const tabs = Array.from(bx.querySelectorAll('.bx-tab'));
        const panels = Array.from(bx.querySelectorAll('.bx-panel'));
        let active = 0;
        let paused = false;
        const render = () => {
            tabs.forEach((t, i) => {
                const on = i === active;
                t.classList.toggle('is-active', on);
                t.classList.toggle('is-paused', on && paused);
                t.setAttribute('aria-selected', String(on));
            });
            panels.forEach((p, i) => p.classList.toggle('is-active', i === active));
        };
        tabs.forEach((t, i) => t.addEventListener('click', () => { active = i; paused = true; render(); }));
        bx.addEventListener('mouseenter', () => { paused = true; render(); });
        bx.addEventListener('mouseleave', () => { paused = false; render(); });
        if (!reduce) setInterval(() => { if (!paused) { active = (active + 1) % tabs.length; render(); } }, 7000);
        render();
    }
})();
